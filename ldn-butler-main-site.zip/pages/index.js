import { useState } from 'react';

export default function Home() {
  const [duration, setDuration] = useState('');
  const [interests, setInterests] = useState('');
  const [budget, setBudget] = useState('');
  const [itinerary, setItinerary] = useState('');

  const handleGenerate = async () => {
    const res = await fetch('/api/itinerary', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ duration, interests: interests.split(','), budget }),
    });
    const data = await res.json();
    if (data.success) setItinerary(data.itinerary);
  };

  return (
    <div className="font-sans px-6 py-8">
      <header className="text-center mb-10">
        <h1 className="text-4xl font-bold">LDN BUTLER 伦敦管家</h1>
        <p className="text-lg text-gray-600">Your One-stop AI-enhanced Travel & Life Butler in London</p>
        <p className="text-sm text-gray-500 mt-2">LDN Butler Ltd | Company No. 16430838</p>
        <p className="text-sm text-gray-500">85 Great Portland Street, London W1W 7LT</p>
      </header>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4">Our Core Services 核心服务</h2>
        <ul className="list-disc ml-6 text-gray-700 space-y-1">
          <li>中文导游服务 / Mandarin-speaking Tour Guides</li>
          <li>行程定制 / Customised UK Travel Planning</li>
          <li>住宿协助 / Airbnb & Hotel Booking Support</li>
          <li>接送机、新生落地、看房陪同 / Arrival & Housing Help</li>
          <li>猫咪寄养、家政清洁、日用品代购 / Local Life Support</li>
        </ul>
      </section>

      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-4">AI Concierge System 智能系统体验</h2>
        <p className="text-gray-700 mb-2">Enter your travel info below to get an AI-generated itinerary.</p>
        <div className="space-x-2 mb-4">
          <input className="border p-2" placeholder="Days in London" value={duration} onChange={e => setDuration(e.target.value)} />
          <input className="border p-2" placeholder="Interests (comma separated)" value={interests} onChange={e => setInterests(e.target.value)} />
          <input className="border p-2" placeholder="Budget (£)" value={budget} onChange={e => setBudget(e.target.value)} />
          <button className="bg-black text-white px-4 py-2" onClick={handleGenerate}>Generate Itinerary</button>
        </div>
        <pre className="bg-gray-100 p-4 rounded whitespace-pre-wrap">{itinerary}</pre>
      </section>

      <footer className="text-center text-sm text-gray-500 mt-12">
        <p>Email: ldnbutler@ldnbutler.com</p>
        <p>WeChat: LDN伦敦管家</p>
        <p>Xiaohongshu: LDN伦敦生活管家</p>
      </footer>
    </div>
  );
}
